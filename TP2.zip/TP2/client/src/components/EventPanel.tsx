import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import type { RootState } from '../models';
import QuestionList from './QuestionList';
import QuestionCanvas from './QuestionCanvas';
import type { PublicEvent } from '../models';

const EventPanel = () => {
  const { eventId } = useParams<{ eventId: string }>();
  const event = useSelector((state: RootState) => 
    (state.events.events as PublicEvent[]).find((e: PublicEvent) => e.id === eventId)
  );
  const isMobile = useSelector((state: RootState) => state.events.isMobile as boolean);

  if (!event) {
    return <div>Event not found</div>;
  }

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">{event.title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <QuestionList eventId={eventId!} />
        {isMobile && <QuestionCanvas eventId={eventId!} />}
      </div>
    </div>
  );
};

export default EventPanel;
