import { useRef, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { setCurrentQuestion } from '../store/slices/eventsSlice';
import type { Question } from '../models';
import OneDollar from '../OneDollar';

interface Props {
  eventId: string;
  questions: Question[];
  currentQuestionId: string;
}

const QuestionCanvas = ({ eventId, questions, currentQuestionId }: Props) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [paint, setPaint] = useState(false);
  const [gesture, setGesture] = useState(false);
  const [gesturePoints, setGesturePoints] = useState<[number, number][]>([]);

  useEffect(() => {
    const recognizer = new OneDollar({
      score: 80,
      parts: 64,
      step: 2,
      angle: 45,
      size: 250,
    });

    // Add gesture patterns
    recognizer.add('left', [[0, 0], [50, 0], [100, 0]]);
    recognizer.add('right', [[100, 0], [50, 0], [0, 0]]);

    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    const handlePointerDown = (ev: PointerEvent) => {
      if (ev.pointerType === 'touch' || ev.pointerType === 'pen') {
        const rect = canvas.getBoundingClientRect();
        const x = (ev.clientX - rect.left) / rect.width;
        const y = (ev.clientY - rect.top) / rect.height;
        
        setPaint(true);
        setGesture(true);
        setGesturePoints([[x, y]]);
        redraw();
      }
    };

    const handlePointerMove = (ev: PointerEvent) => {
      if (paint && (ev.pointerType === 'touch' || ev.pointerType === 'pen')) {
        const rect = canvas.getBoundingClientRect();
        const x = (ev.clientX - rect.left) / rect.width;
        const y = (ev.clientY - rect.top) / rect.height;
        
        setGesturePoints(prev => [...prev, [x, y]]);
        redraw();
      }
    };

    const handlePointerUp = () => {
      if (paint) {
        setPaint(false);
        setGesture(false);

        // Convert points for gesture recognition
        const points = gesturePoints.map(([x, y]) => [x * canvas.width, y * canvas.height] as [number, number]);
        const result = recognizer.check(points);

        if (result && typeof result !== 'boolean') {
          handleGestureRecognized(result.name);
        }

        setGesturePoints([]);
        redraw();
      }
    };

    canvas.addEventListener('pointerdown', handlePointerDown);
    canvas.addEventListener('pointermove', handlePointerMove);
    canvas.addEventListener('pointerup', handlePointerUp);
    canvas.addEventListener('pointerout', handlePointerUp);

    return () => {
      canvas.removeEventListener('pointerdown', handlePointerDown);
      canvas.removeEventListener('pointermove', handlePointerMove);
      canvas.removeEventListener('pointerup', handlePointerUp);
      canvas.removeEventListener('pointerout', handlePointerUp);
    };
  }, [paint, gesturePoints]);

  const handleGestureRecognized = (gestureName: string) => {
    const currentIndex = questions.findIndex((q: Question) => q.id === currentQuestionId);
    if (currentIndex === -1) return;

    let nextIndex: number;
    if (gestureName === 'left' && currentIndex > 0) {
      nextIndex = currentIndex - 1;
    } else if (gestureName === 'right' && currentIndex < questions.length - 1) {
      nextIndex = currentIndex + 1;
    } else {
      return;
    }

    const nextQuestion = questions[nextIndex];
    dispatch(setCurrentQuestion(nextQuestion.id));
    navigate(`/event/${eventId}/question/${nextQuestion.id}`);
  };

  const redraw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const context = canvas.getContext('2d');
    if (!context) return;

    const width = canvas.width;
    const height = canvas.height;

    context.clearRect(0, 0, width, height);

    if (gesture && gesturePoints.length > 0) {
      context.strokeStyle = '#666';
      context.lineJoin = 'round';
      context.lineWidth = 5;

      context.beginPath();
      context.moveTo(gesturePoints[0][0] * width, gesturePoints[0][1] * height);
      
      for (let i = 1; i < gesturePoints.length; i++) {
        context.lineTo(gesturePoints[i][0] * width, gesturePoints[i][1] * height);
      }
      
      context.stroke();
    }
  };

  return (
    <div className="w-full h-full">
      <canvas
        ref={canvasRef}
        className="w-full h-full touch-none"
        style={{ backgroundColor: '#f0f0f0' }}
      />
    </div>
  );
};

export default QuestionCanvas;
