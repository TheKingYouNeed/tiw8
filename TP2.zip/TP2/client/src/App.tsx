import { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store';
import AppToolbar from './components/AppToolbar';
import EventPanel from './components/EventPanel';
import { isMobile } from 'react-device-detect';
import { setMobile } from './store/slices/eventsSlice';

function App() {
  useEffect(() => {
    store.dispatch(setMobile(isMobile));
  }, []);

  return (
    <Provider store={store}>
      <Router>
        <div className="min-h-screen bg-gray-100">
          <AppToolbar />
          <main className="container mx-auto py-6 px-4">
            <Routes>
              <Route path="/" element={<Navigate to="/events" replace />} />
              <Route path="/events" element={<div className="text-center text-xl">Select an event to begin</div>} />
              <Route path="/event/:eventId" element={<EventPanel />} />
              <Route path="/event/:eventId/question/:questionId" element={<EventPanel />} />
            </Routes>
          </main>
          <footer className="bg-gray-800 text-white py-4 mt-8">
            <div className="container mx-auto text-center">
              <p>TIW8 - TP2 Q&A Application</p>
            </div>
          </footer>
        </div>
      </Router>
    </Provider>
  );
}

export default App;
