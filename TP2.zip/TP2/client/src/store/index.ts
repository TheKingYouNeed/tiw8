import { configureStore } from '@reduxjs/toolkit';
import eventsReducer from './slices/eventsSlice';
import type { RootState } from '../models';

export const store = configureStore({
  reducer: {
    events: eventsReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware(),
});

export type AppDispatch = typeof store.dispatch;
export type { RootState } from '../models';
