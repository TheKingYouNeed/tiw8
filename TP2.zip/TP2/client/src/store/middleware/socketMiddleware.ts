import { Middleware } from 'redux';
import { io, Socket } from 'socket.io-client';
import { AppDispatch, RootState } from '..';
import { addEvent, addQuestion, setEvents, upvoteQuestion } from '../slices/eventsSlice';

const SOCKET_URL = 'http://localhost:3000';

export const socketMiddleware: Middleware<{}, RootState, AppDispatch> = (store) => {
  let socket: Socket;

  return next => action => {
    if (!socket) {
      socket = io(SOCKET_URL);

      socket.on('connect', () => {
        console.log('Connected to server');
      });

      socket.on('events', (events) => {
        store.dispatch(setEvents(events));
      });

      socket.on('action', (action) => {
        console.log('Received action:', action);
        switch (action.type) {
          case 'addEvent':
            store.dispatch(addEvent(action.payload));
            break;
          case 'addQuestion':
            store.dispatch(addQuestion(action.payload));
            break;
          case 'upvoteQuestion':
            store.dispatch(upvoteQuestion(action.payload));
            break;
          default:
            break;
        }
      });

      socket.on('disconnect', () => {
        console.log('Disconnected from server');
      });
    }

    // Propagate certain actions to the server
    if (
      action.type === 'events/addEvent' ||
      action.type === 'events/addQuestion' ||
      action.type === 'events/upvoteQuestion'
    ) {
      socket.emit('action', action);
    }

    return next(action);
  };
};
