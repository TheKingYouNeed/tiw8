import path from "path";
import express from "express";
import cors from "cors";
import { createServer } from "http";
import { Server } from "socket.io";
import { PublicEvent, Question } from "./models";

const app = express();
app.use(cors());

const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
  },
});

// Configuration des chemins pour servir les fichiers statiques
const DIST_DIR = path.join(__dirname, "../../client/dist");
const HTML_FILE = path.join(DIST_DIR, "index.html");

// Middleware pour servir les fichiers statiques
app.use(express.static(DIST_DIR));

// Middleware pour parser le JSON
app.use(express.json());

let events: PublicEvent[] = [
  {
    id: '1',
    title: 'Introduction to React',
    description: 'Learn the basics of React and its ecosystem',
    questions: [
      {
        id: '1',
        text: 'What is JSX?',
        content: 'Please explain the concept of JSX in React',
        type: 'text',
        votes: 0,
        author: 'student1',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: '2',
        text: 'How do hooks work?',
        content: 'Can you explain React hooks and their benefits?',
        type: 'text',
        votes: 0,
        author: 'student2',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '2',
    title: 'Redux Workshop',
    description: 'Deep dive into Redux and state management',
    questions: [
      {
        id: '3',
        text: 'What is a reducer?',
        content: 'Please explain the concept of reducers in Redux',
        type: 'text',
        votes: 0,
        author: 'student3',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// Socket.io event handling
io.on("connection", (socket) => {
  console.log("Client connected");

  // Send current events to the newly connected client
  socket.emit("events", events);

  // Handle incoming actions
  socket.on("action", (msg) => {
    console.log("Action received:", msg);
    // Broadcast the action to all other clients
    socket.broadcast.emit("action", msg);
  });

  socket.on("disconnect", () => {
    console.log("Client disconnected");
  });
});

// API Routes
app.get("/", (req, res) => {
  res.sendFile(HTML_FILE);
});

app.get("/api/events", (req, res) => {
  res.json(events);
});

app.post("/api/events", (req, res) => {
  const event = req.body as PublicEvent;
  events.push(event);
  io.emit("eventCreated", event);
  res.status(201).json(event);
});

app.post("/api/events/:eventId/questions", (req, res) => {
  const { eventId } = req.params;
  const question = req.body;
  const event = events.find(e => e.id === eventId);
  
  if (!event) {
    return res.status(404).json({ error: "Event not found" });
  }

  event.questions.push(question);
  io.emit("questionCreated", { eventId, question });
  res.status(201).json(question);
});

// Start server
const port = process.env.PORT || 3000;
httpServer.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
